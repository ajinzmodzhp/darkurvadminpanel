async function api(path, method='GET', body=null){
  const opts = { method, headers: {'Content-Type':'application/json'} };
  if(body) opts.body = JSON.stringify(body);
  const res = await fetch('/api'+path, opts);
  return res.json();
}

function showModal(html){
  document.getElementById('modalcontent').innerHTML = html;
  document.getElementById('modal').classList.remove('hidden');
}
document.getElementById('closemodal').onclick = ()=> document.getElementById('modal').classList.add('hidden');

document.getElementById('keygen').onclick = ()=>{
  showModal(`<h2 class="text-xl font-bold mb-2">Create Key</h2>
  <div class="space-y-2">
  <input id="kg_user" placeholder="username" class="w-full p-2 rounded bg-gray-700"/>
  <input id="kg_pass" placeholder="password" class="w-full p-2 rounded bg-gray-700"/>
  <select id="kg_dur" class="w-full p-2 rounded bg-gray-700">
    <option value="1h">1 hour</option>
    <option value="1d">1 day</option>
    <option value="3d">3 days</option>
    <option value="5d">5 days</option>
    <option value="7d">7 days</option>
    <option value="13d">13 days</option>
  </select>
  <div class="flex justify-end mt-3"><button id="kg_submit" class="px-4 py-2 bg-indigo-600 rounded">Create</button></div>
  </div>`);
  document.getElementById('kg_submit').onclick = async ()=>{
    const username = document.getElementById('kg_user').value;
    const password = document.getElementById('kg_pass').value;
    const duration = document.getElementById('kg_dur').value;
    const r = await api('/key','POST',{username,password,duration});
    document.getElementById('output').innerText = JSON.stringify(r, null, 2);
    document.getElementById('modal').classList.add('hidden');
  };
};

document.getElementById('toggleinj').onclick = async ()=>{
  const r = await api('/toggle-inj','POST',{});
  document.getElementById('output').innerText = JSON.stringify(r, null, 2);
};

document.getElementById('deluser').onclick = ()=>{
  showModal(`<h2 class="text-xl font-bold mb-2">Delete User</h2>
  <input id="del_username" placeholder="username to delete" class="w-full p-2 rounded bg-gray-700"/>
  <div class="flex justify-end mt-3"><button id="del_submit" class="px-4 py-2 bg-yellow-600 rounded">Delete</button></div>`);
  document.getElementById('del_submit').onclick = async ()=>{
    const name = document.getElementById('del_username').value;
    const r = await api('/user/'+encodeURIComponent(name),'DELETE');
    document.getElementById('output').innerText = JSON.stringify(r, null, 2);
    document.getElementById('modal').classList.add('hidden');
  };
};

document.getElementById('listact').onclick = async ()=>{
  const r = await api('/keys');
  let out = '';
  if(r.users && r.users.length){
    out += 'Active users/keys:\\n\\n';
    r.users.forEach(u=>{
      let exp = u.expires ? new Date(u.expires).toLocaleString() : 'never';
      out += `username: ${u.username} | key: ${u.key} | expires: ${exp}\\n`;
    });
  } else out = 'No active users';
  document.getElementById('output').innerText = out;
};

// initial status fetch
(async ()=>{
  const s = await api('/status');
  document.getElementById('output').innerText = 'Status:\\n' + JSON.stringify(s,null,2);
})();
